
from flask import Flask, render_template_string
from database import get_all_workers

app = Flask(__name__)

HTML = '''
<!DOCTYPE html>
<html>
<head>
    <title>لیست کارگران</title>
    <style>
        body { font-family: sans-serif; direction: rtl; text-align: right; }
        table { width: 100%%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ccc; padding: 8px; }
        img { height: 100px; }
    </style>
</head>
<body>
    <h2>لیست کارگران ثبت‌شده</h2>
    <table>
        <tr>
            <th>آی‌دی</th>
            <th>مهارت</th>
            <th>حقوق</th>
            <th>عکس</th>
            <th>موقعیت</th>
        </tr>
        {% for w in workers %}
        <tr>
            <td>{{ w[0] }}</td>
            <td>{{ w[1] }}</td>
            <td>{{ w[2] }}</td>
            <td><img src="{{ w[3] }}"></td>
            <td>{{ w[4] }}, {{ w[5] }}</td>
        </tr>
        {% endfor %}
    </table>
</body>
</html>
'''

@app.route("/")
def index():
    workers = get_all_workers()
    return render_template_string(HTML, workers=workers)

if __name__ == "__main__":
    app.run(debug=True)
