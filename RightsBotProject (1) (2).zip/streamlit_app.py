
import streamlit as st
from database import get_all_workers

st.set_page_config(layout="wide")
st.title("لیست کارگران ثبت‌شده")

workers = get_all_workers()
for w in workers:
    st.markdown("---")
    col1, col2 = st.columns([1, 3])
    with col1:
        st.image(w[3], width=150)
    with col2:
        st.markdown(f"**آی‌دی:** {w[0]}")
        st.markdown(f"**مهارت:** {w[1]}")
        st.markdown(f"**حقوق:** {w[2]}")
        st.markdown(f"**موقعیت:** {w[4]}, {w[5]}")
