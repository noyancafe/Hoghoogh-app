
import sqlite3
conn = sqlite3.connect('workers.db', check_same_thread=False)
cursor = conn.cursor()
cursor.execute('''CREATE TABLE IF NOT EXISTS workers (
    user_id INTEGER,
    skill TEXT,
    salary TEXT,
    photo_url TEXT,
    latitude REAL,
    longitude REAL
)''')
def add_worker(user_id, skill, salary, photo_url, latitude, longitude):
    cursor.execute("INSERT INTO workers (user_id, skill, salary, photo_url, latitude, longitude) VALUES (?, ?, ?, ?, ?, ?)",
                   (user_id, skill, salary, photo_url, latitude, longitude))
    conn.commit()
def get_all_workers():
    cursor.execute("SELECT * FROM workers")
    return cursor.fetchall()
