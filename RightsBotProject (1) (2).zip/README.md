
# حقوق Rights Bot

ربات تلگرام برای ثبت اطلاعات کارگران و تطبیق با کارفرمایان

## نصب
```
pip install python-telegram-bot google-api-python-client google-auth google-auth-oauthlib
```

## اجرا
- توکن را در `config.json` وارد کنید.
- فایل `credentials.json` را قرار دهید.
- سپس اجرا کنید:
```
python bot.py
```
