
import json
import logging
from telegram import Update, KeyboardButton, ReplyKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes, ConversationHandler
from database import add_worker
from drive_upload import upload_photo_to_drive

logging.basicConfig(level=logging.INFO)
with open("config.json") as f:
    config = json.load(f)

PHOTO, LOCATION, SKILL, SALARY = range(4)
user_data = {}

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("سلام! لطفاً عکس خود را ارسال کنید.")
    return PHOTO

async def photo_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    photo = update.message.photo[-1]
    file = await photo.get_file()
    file_path = f"{update.message.from_user.id}_photo.jpg"
    await file.download_to_drive(file_path)
    url = upload_photo_to_drive(file_path, file_path)
    user_data[update.message.from_user.id] = {"photo_url": url}
    await update.message.reply_text("مهارت شما چیست؟")
    return SKILL

async def skill_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_data[update.message.from_user.id]["skill"] = update.message.text
    await update.message.reply_text("حقوق مورد نظرتان را وارد کنید.")
    return SALARY

async def salary_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_data[update.message.from_user.id]["salary"] = update.message.text
    await update.message.reply_text("اکنون موقعیت مکانی خود را ارسال کنید.", reply_markup=ReplyKeyboardMarkup(
        [[KeyboardButton("ارسال موقعیت", request_location=True)]], one_time_keyboard=True, resize_keyboard=True))
    return LOCATION

async def location_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    lat = update.message.location.latitude
    lon = update.message.location.longitude
    data = user_data[update.message.from_user.id]
    add_worker(update.message.from_user.id, data["skill"], data["salary"], data["photo_url"], lat, lon)
    await update.message.reply_text("ثبت‌نام شما با موفقیت انجام شد.")
    return ConversationHandler.END

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("لغو شد.")
    return ConversationHandler.END

def main():
    app = ApplicationBuilder().token(config["TELEGRAM_TOKEN"]).build()
    conv_handler = ConversationHandler(
        entry_points=[CommandHandler("start", start)],
        states={
            PHOTO: [MessageHandler(filters.PHOTO, photo_handler)],
            SKILL: [MessageHandler(filters.TEXT & ~filters.COMMAND, skill_handler)],
            SALARY: [MessageHandler(filters.TEXT & ~filters.COMMAND, salary_handler)],
            LOCATION: [MessageHandler(filters.LOCATION, location_handler)],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
    )
    app.add_handler(conv_handler)
    app.run_polling()

if __name__ == "__main__":
    main()
